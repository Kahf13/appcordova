<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect('localhost', 'id12789078_kahf13', 'Kahf13', 'id12789078_mahasiswa') or die ("could not connect database");
?>